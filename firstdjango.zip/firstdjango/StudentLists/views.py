from django.http import HttpResponse 
from django.shortcuts import render
from django.views.generic import TemplateView
from .models import Studentlists 
from .forms import StudentCreateForm
# Create your views here.




def Student_createview(request):
	form = StudentCreateForm(request.POST or None)
	if request.method=="POST":
		if form.is_valid():
			form.save()


	context = {
		'form' : form
	}
	return render(request, "form.html" , context) 





def Student_List_Details(request):
    queryset = Studentlists.objects.all()
    context = {
		"object_list": queryset
    }		
    return render(request, "Student_list.html" , context) 



