from django.apps import AppConfig


class StudentlistsConfig(AppConfig):
    name = 'studentlists'
