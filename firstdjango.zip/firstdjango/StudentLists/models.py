from django.db import models

# Create your models here.
class Studentlists(models.Model):
	  name   = models.CharField(max_length=100,blank=False)
	  age    = models.IntegerField(blank=False)
	  gender = models.CharField(max_length=100,blank=False)


