from django import forms
from .models import Studentlists

categories= ( ('male','male'),('female','female'))
class StudentCreateForm(forms.ModelForm):
	gender= forms.ChoiceField(choices=categories, required=True)  
	class Meta:
		model = Studentlists
		fields = ['name' ,'age' ,'gender']
